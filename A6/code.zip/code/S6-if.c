int a=1;
int b=2;
int max;

void foo () {
  if (a>b)
    max = a;
  else
    max = b;
}
